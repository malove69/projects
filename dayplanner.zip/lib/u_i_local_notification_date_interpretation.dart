class UILocalNotificationDateInterpretation {
  static var wallClockTime;
}

